package Holder;
use Foo;
1;
