package LWP::DebugFile;

our $VERSION = '6.35';

# legacy stub

1;
